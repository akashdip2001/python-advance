# Python for DevOps

- Day 1
01) Introduction
02) Python Basics for DevOps
03) Control Flow & Functions

- Day 2
04) File & Process Automation
05) Networking & API Interactions
06) Core Date Structures (DSA)
07) OOP
08) Infrastructure as Code

- Day 3
09) CI/CD & Integration
10) Monitoring & Logging
11) Advance Python for DevOps
12) Python Libraries for DevOps
13) Projects
14) Resources & Guide