from DevOps_command import run_command

def docker_run():
    run_command("docker run ubuntu")

# github link : https://github.com/LondheShubham153/python-masterclass/blob/master/intermediate/terra_deploy.py

