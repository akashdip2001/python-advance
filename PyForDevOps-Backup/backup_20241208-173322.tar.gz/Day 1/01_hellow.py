print("Hellow Akashdip") #function to print the string
print(2+2)
