# # Type Casting
# a=1
# print(a)
# print(float(a))



# # Input
# city = input("Enter your city Name !")
# # print("Your city name is :",city)
# print(f"Your city name is : {city}")



# Manipulate Strings
name1 = input("Enter your name :")
name2 = input("Enter Your Frd. name :")

about = f"Hellow friends, this is {name1}"
print(about)

x = about.replace("friends",name2)
print(x)

print(dir(about))