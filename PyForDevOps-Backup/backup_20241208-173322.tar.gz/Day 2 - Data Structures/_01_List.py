## List

envirorment = ["dev", "prd", "stg", "test"]
# print(dir(envirorment))

print(len(envirorment))
# output: 4 (0, 1, 2, 3)

envirorment.append("bastion")
print(envirorment)

# You dont know What is append ??
print(envirorment.append.__doc__) # docomentation
