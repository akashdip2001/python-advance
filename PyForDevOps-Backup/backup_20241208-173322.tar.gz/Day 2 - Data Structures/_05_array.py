# array
# not core Data Structure in python
# array is a module in python

## array is a list of elements of the same type
## array is faster than list
## array is used when we need to store large number of elements of the same type

import array

arr = array.array('i', [1, 2, 3, 4, 5])
print(arr)
print(arr[0])
print(arr[1])
print(arr[2])

